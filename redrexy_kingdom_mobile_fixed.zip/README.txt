𝚛𝚎𝚍𝚛𝚎𝚡𝚢 𝚔𝚒𝚗𝚐𝚍𝚘𝚖 v2
- Open index.html to preview.
- Discord and email are already added.
- Edit prices/products in index.html.
- This is a static storefront UI. Real automatic payments, accounts, file delivery and order database need a backend/payment provider.
